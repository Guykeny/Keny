// Question 1
// Ajout de la ligne d'en-têtes (horaires) au tableau HTML et suppression de la liste

// Question 2
// Configuration des labels
var t_labels = [ "Neutre", "Interdit", "A éviter", "Préféré"];
var c_labels = [ "white", "red", "orange", "green"];

// Question 3
// Configuration des boutons radio

// Question 4
// Ajout du bouton de soumission

// Question 5
// Ajout de l'élément `form`
