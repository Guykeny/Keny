function toNumber(s) {

}
