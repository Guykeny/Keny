// Question 1 : Coloration


// Question 2 : Centrer images de la div intro 


// Question 3 : Ajout indication sondage


// Question 4 : Ajout d'une description textuelle aux images
